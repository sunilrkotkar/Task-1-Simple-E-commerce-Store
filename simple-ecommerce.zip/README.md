# Simple E-commerce Store

## Setup
1. Install dependencies:
```sh
cd backend
npm install
```
2. Run MongoDB and start the server:
```sh
npm start
```
3. Open `frontend/index.html` in a browser.