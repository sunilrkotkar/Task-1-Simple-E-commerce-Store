const express = require('express'); const Order = require('../models/Order'); const router = express.Router();
router.post('/', async (req, res) => { const { items, totalAmount } = req.body; const newOrder = new Order({ items, totalAmount }); await newOrder.save(); res.json(newOrder); });
module.exports = router;